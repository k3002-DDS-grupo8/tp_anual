docker build --rm -t auth0-javascript-sample-01-login .
docker run -p 3000:3000 -it auth0-javascript-sample-01-login
